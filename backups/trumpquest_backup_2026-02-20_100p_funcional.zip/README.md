# Game-AI-Test
A fast-paced top-down action game where players explore a dynamic world, gather resources, upgrade abilities, and survive escalating challenges. Designed for smooth local performance, it combines strategic movement, combat, and progression in an immersive gameplay loop.
